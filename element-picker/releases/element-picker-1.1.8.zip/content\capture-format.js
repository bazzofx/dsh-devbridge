/*
 * capture-format.js — capture-block text/JSON (compact, ELEMENT-CAPTURE v1.1).
 * Loaded by: picker content script, send.js content script, popup page.
 * Exposes globalThis.DSHPC.captureText(capture).
 *
 * Outbound format: ONE JSON object with exactly the fields
 * { url, selector, xpath, text, comment }. No Markdown duplicate, no marker,
 * no capturedAt/tag/markup/html in what is sent. History fields (capturedAt,
 * id, tag, markup) stay stored locally for the popup UI but never travel to
 * the chat. The selector is verified unique at capture; the agent re-verifies
 * it on the URL before acting.
 */
(() => {
  'use strict';

  const VERSION = 'v1.1';
  const MARKER = 'ELEMENT-CAPTURE';

  const esc = (s) => String(s == null ? '' : s).trim();

  function captureText(c) {
    const comment = String(c.comment || '').trim();
    // Single JSON object, nothing duplicated. History-only fields (capturedAt,
    // id, tag, markup) stay stored locally for the UI and never travel here.
    const payload = {
      url: c.url || null,
      selector: c.selector || null,
      xpath: c.xpath || null,
      text: c.text || null,
      comment: comment || null
    };
    return JSON.stringify(payload);
  }

  globalThis.DSHPC = Object.assign(globalThis.DSHPC || {}, {
    VERSION,
    MARKER,
    captureText
  });
})();