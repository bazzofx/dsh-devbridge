/*
 * capture-format.js — capture-block text/JSON (compact, ELEMENT-CAPTURE v1.1).
 * Loaded by: picker content script, send.js content script, popup page.
 * Exposes globalThis.DSHPC.captureText(capture).
 *
 * v1.1 drops the redundant XPath and the large outerHTML dump. A capture now
 * carries: URL, unique verified CSS selector, tag, short visible text, a
 * compact opening-tag markup snapshot (attributes only, greppable in source)
 * and the user's comment. Accuracy is preserved because the selector is
 * verified unique at capture time and the agent re-verifies it on the URL
 * before acting. Legacy captures that still contain html/xpath render as-is.
 */
(() => {
  'use strict';

  const VERSION = 'v1.1';
  const MARKER = 'ELEMENT-CAPTURE';

  const esc = (s) => String(s == null ? '' : s).trim();

  function captureText(c) {
    const comment = esc(c.comment);
    const markup = String(c.markup || '').slice(0, 300);

    const lines = [
      `<!-- ${MARKER} ${VERSION} -->`,
      `Captured: ${c.capturedAt || new Date().toISOString()}`,
      `URL: ${c.url || ''}`,
      `Selector: ${c.selector || ''}`,
      `Tag: ${String(c.tag || '').toUpperCase()}  Text: "${c.text || ''}"`,
      `Comment: ${comment ? comment.replace(/\n/g, '\n          ') : '(none)'}`
    ];
    if (markup) lines.push(`Markup: ${markup}`);

    const md = lines.join('\n');

    const payload = {
      marker: `${MARKER} ${VERSION}`,
      capturedAt: c.capturedAt || null,
      url: c.url || null,
      selector: c.selector || null,
      tag: c.tag ? String(c.tag).toUpperCase() : null,
      text: c.text || null,
      comment: comment || null
    };
    if (markup) payload.markup = markup;
    const json = JSON.stringify(payload, null, 2);

    return md + '\n\n---\n' + json;
  }

  globalThis.DSHPC = Object.assign(globalThis.DSHPC || {}, {
    VERSION,
    MARKER,
    captureText
  });
})();